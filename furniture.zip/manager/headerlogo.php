<header class="factory">
	<nav class="main-nav center">
		<div class="nav-wrapper section-rule">
			<a href="../index.php" class="brand-logo" target="_blank">
				<img src="../images/hdhublogo.png" alt="">
			</a>
		</div>
	</nav>
</header>


